package com.example.pharmacistApp.data

import java.util.Date

enum class ActivityType {
    NEW_USER,
    NEW_ORDER,
    PHARMACY_APPLICATION,
    COMPLAINT
}